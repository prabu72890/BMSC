# Bored_Macaw_Sol_Club
 Bored Macaw Sol Club is a collection of 10,000  NFTs unique digital collectibles Flying onSolana blockchain. Our Macaws is Generated up with over a Hundred exciting Traits of Faces, Heads, Hats, Bodies, Cloths and Backgrounds. Each Macaw is 1080 x 1080 pixels and unique in order to prioritize quality above quantity. 
